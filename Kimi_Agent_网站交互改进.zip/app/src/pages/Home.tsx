import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import OrderTab from "@/components/OrderTab";
import MyOrdersTab from "@/components/MyOrdersTab";
import ProfileTab from "@/components/ProfileTab";
import { fmtPoints } from "@/lib/format";

type TabKey = "order" | "orders" | "me";

const TABS: Array<{ key: TabKey; icon: string; label: string }> = [
  { key: "order", icon: "📋", label: "点单" },
  { key: "orders", icon: "🕒", label: "订单" },
  { key: "me", icon: "👤", label: "我的" },
];

export default function Home() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const [tab, setTab] = useState<TabKey>("order");

  if (isLoading || !user) {
    return (
      <div className="min-h-dvh flex items-center justify-center text-sm text-neutral-400">
        加载中…
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-neutral-200 flex justify-center">
      <div className="relative w-full max-w-[480px] h-dvh bg-white flex flex-col overflow-hidden shadow-xl">
        {/* 顶部状态条 */}
        <div className="bg-neutral-100 px-4 py-2.5 text-xs text-neutral-600 flex items-center justify-center gap-1">
          <span className="text-emerald-600">🛡️</span> 王豆豆的专属订单 · 在线点单
        </div>

        {/* 头部 */}
        <div className="px-4 pt-3 bg-white">
          <div className="flex justify-between items-start">
            <div className="text-xl font-bold text-neutral-900 tracking-wide">王豆豆的专属订单</div>
            <div className="flex items-center gap-2">
              <span className="text-[13px] text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                积分 {fmtPoints(user.points)}
              </span>
            </div>
          </div>
          <div className="mt-2 text-[13px] text-neutral-500 flex items-center gap-1.5">
            <span className="text-amber-500 text-[11px] tracking-wider">★★★★★</span> 4.8 | 只属于我们的记忆
          </div>
        </div>

        {/* 内容区 */}
        {tab === "order" && <OrderTab />}
        {tab === "orders" && <MyOrdersTab />}
        {tab === "me" && <ProfileTab />}

        {/* 底部 TabBar */}
        <div className="absolute bottom-0 left-0 right-0 h-[60px] bg-white flex border-t border-neutral-100 pb-[env(safe-area-inset-bottom)] z-30">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 flex flex-col items-center justify-center gap-[3px] text-[11px] ${
                tab === t.key ? "text-neutral-900 font-bold" : "text-neutral-500"
              }`}
            >
              <span className="text-xl">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
