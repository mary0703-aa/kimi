import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="min-h-dvh bg-neutral-100 flex items-center justify-center px-6">
      <Card className="w-full max-w-sm border-neutral-100 shadow-lg">
        <CardHeader className="text-center pb-2">
          <div className="text-4xl mb-2">🛡️</div>
          <CardTitle className="text-xl">王豆豆的专属订单</CardTitle>
          <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">
            登录后开始点单；店主账号可进入管理后台接单、管理积分
          </p>
        </CardHeader>
        <CardContent>
          <Button
            className="w-full bg-neutral-900 hover:bg-neutral-700 text-white"
            size="lg"
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
          >
            使用 Kimi 账号登录
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
