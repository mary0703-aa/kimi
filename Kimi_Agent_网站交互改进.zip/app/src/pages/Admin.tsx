import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { ORDER_STATUS_LABELS } from "@contracts/constants";
import { fmtPoints, fmtTime } from "@/lib/format";

type TabKey = "orders" | "users" | "logs" | "menu";

const ADMIN_TABS: Array<{ key: TabKey; icon: string; label: string }> = [
  { key: "orders", icon: "🔔", label: "订单" },
  { key: "users", icon: "👥", label: "用户积分" },
  { key: "logs", icon: "📒", label: "积分流水" },
  { key: "menu", icon: "🍽️", label: "菜单" },
];

let sharedCtx: AudioContext | null = null;

// 浏览器自动播放策略：首次用户交互时预热 AudioContext
if (typeof window !== "undefined") {
  const warmUp = () => {
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      sharedCtx = sharedCtx ?? new Ctx();
      if (sharedCtx.state === "suspended") void sharedCtx.resume();
    } catch {
      /* 无音频环境时静默 */
    }
  };
  window.addEventListener("pointerdown", warmUp, { once: true });
}

function beep() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = sharedCtx ?? new Ctx();
    sharedCtx = ctx;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    osc.start();
    osc.stop(ctx.currentTime + 0.4);
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* 无音频环境时静默 */
  }
}

export default function Admin() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const navigate = useNavigate();
  const [tab, setTab] = useState<TabKey>("orders");

  if (isLoading || !user) {
    return (
      <div className="min-h-dvh flex items-center justify-center text-sm text-neutral-400">加载中…</div>
    );
  }
  if (user.role !== "admin") {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center gap-3 text-neutral-400">
        <span className="text-4xl">🔒</span>
        <span className="text-sm">暂无权限访问管理后台</span>
        <button onClick={() => navigate("/")} className="text-sm underline text-neutral-600">
          返回点单页
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-neutral-200 flex justify-center">
      <div className="relative w-full max-w-[480px] h-dvh bg-neutral-50 flex flex-col overflow-hidden shadow-xl">
        <div className="bg-neutral-900 text-white px-4 py-3.5 flex items-center gap-2.5 shrink-0">
          <button onClick={() => navigate("/")} className="text-lg leading-none" aria-label="返回">
            ←
          </button>
          <div className="flex-1">
            <div className="font-bold text-[15px]">管理后台</div>
            <div className="text-[11px] text-neutral-400">接单提醒 · 积分管理 · 菜单管理</div>
          </div>
          <span className="text-[11px] bg-neutral-700 rounded-full px-2.5 py-1">{user.name}</span>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col">
          {tab === "orders" && <OrdersPanel />}
          {tab === "users" && <UsersPanel />}
          {tab === "logs" && <LogsPanel />}
          {tab === "menu" && <MenuPanel />}
        </div>

        <div className="h-[60px] bg-white flex border-t border-neutral-100 pb-[env(safe-area-inset-bottom)] shrink-0">
          {ADMIN_TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 flex flex-col items-center justify-center gap-[3px] text-[11px] ${
                tab === t.key ? "text-neutral-900 font-bold" : "text-neutral-500"
              }`}
            >
              <span className="text-xl">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- 订单面板（轮询 + 新单提醒） ---------------- */
function OrdersPanel() {
  const utils = trpc.useUtils();
  const { data: orders } = trpc.admin.orders.useQuery(undefined, {
    refetchInterval: 4000,
  });
  const setStatus = trpc.admin.setOrderStatus.useMutation({
    onSuccess: async () => {
      toast.success("订单状态已更新");
      await utils.admin.orders.invalidate();
      await utils.shop.myOrders.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const seenRef = useRef<Set<number> | null>(null);
  const latestCount = orders?.length ?? 0;

  useEffect(() => {
    if (!orders) return;
    if (seenRef.current === null) {
      seenRef.current = new Set(orders.map((o) => o.id));
      return;
    }
    const fresh = orders.filter((o) => !seenRef.current!.has(o.id) && o.status === "pending");
    fresh.forEach((o) => {
      seenRef.current!.add(o.id);
      beep();
      toast(`🔔 新订单 #${o.id}：${o.user?.name ?? "未知用户"} 点了 ${(o.items as Array<{ name: string; qty: number }>).map((i) => `${i.name}×${i.qty}`).join("、")}`, {
        duration: 6000,
      });
    });
    orders.forEach((o) => seenRef.current!.add(o.id));
  }, [orders]);

  const pendingCount = useMemo(
    () => orders?.filter((o) => o.status === "pending").length ?? 0,
    [orders],
  );

  if (!orders) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">加载中…</div>;
  }

  const actions = (o: (typeof orders)[number]) => {
    if (o.status === "pending") {
      return (
        <>
          <ActionBtn label="✓ 接单" onClick={() => setStatus.mutate({ orderId: o.id, status: "accepted" })} primary />
          <ActionBtn label="取消并退积分" danger onClick={() => setStatus.mutate({ orderId: o.id, status: "cancelled" })} />
        </>
      );
    }
    if (o.status === "accepted") {
      return (
        <>
          <ActionBtn label="✓ 完成" onClick={() => setStatus.mutate({ orderId: o.id, status: "completed" })} primary />
          <ActionBtn label="取消并退积分" danger onClick={() => setStatus.mutate({ orderId: o.id, status: "cancelled" })} />
        </>
      );
    }
    return null;
  };

  return (
    <div className="flex-1 overflow-y-auto px-3 py-3 pb-6 space-y-3">
      <div className="text-xs text-neutral-400 px-1">
        每 4 秒自动刷新 · 待接单 {pendingCount} 单 · 共 {latestCount} 单
      </div>
      {orders.length === 0 && (
        <div className="text-center text-neutral-300 text-sm py-16">暂无订单</div>
      )}
      {orders.map((o) => (
        <div
          key={o.id}
          className={`bg-white rounded-xl border p-3.5 shadow-sm ${
            o.status === "pending" ? "border-amber-300" : "border-neutral-100"
          }`}
        >
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-sm">
              #{o.id} · {o.user?.name ?? "未知用户"}
              {o.status === "pending" && (
                <span className="ml-2 text-[10px] bg-amber-100 text-amber-700 rounded-full px-1.5 py-0.5">新！</span>
              )}
            </span>
            <span className="text-[11px] text-neutral-400">{fmtTime(o.createdAt)}</span>
          </div>
          <div className="space-y-0.5">
            {(o.items as Array<{ name: string; points: number; qty: number }>).map((it, idx) => (
              <div key={idx} className="flex justify-between text-sm">
                <span className="text-neutral-700">{it.name} ×{it.qty}</span>
                <span className="text-neutral-400">{fmtPoints(it.points * it.qty)}</span>
              </div>
            ))}
          </div>
          {o.note && (
            <div className="text-xs text-neutral-500 mt-1.5 bg-neutral-50 rounded-lg px-2.5 py-1.5">💬 {o.note}</div>
          )}
          <div className="flex justify-between items-center mt-2 pt-2 border-t border-neutral-50">
            <span className="text-xs text-neutral-400">{ORDER_STATUS_LABELS[o.status]}</span>
            <span className="font-bold text-sm">{fmtPoints(o.totalPoints)} 积分</span>
          </div>
          <div className="flex gap-2 mt-2.5">{actions(o)}</div>
        </div>
      ))}
    </div>
  );
}

function Avatar({ name, url, size }: { name: string; url?: string | null; size: string }) {
  const [err, setErr] = useState(false);
  if (url && !err) {
    return (
      <img
        src={url}
        alt=""
        referrerPolicy="no-referrer"
        onError={() => setErr(true)}
        className={`${size} rounded-full bg-neutral-100 object-cover shrink-0`}
      />
    );
  }
  return (
    <div className={`${size} rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold shrink-0`}>
      {(name || "?").slice(0, 1)}
    </div>
  );
}

function ActionBtn({
  label,
  onClick,
  primary,
  danger,
}: {
  label: string;
  onClick: () => void;
  primary?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-2 rounded-lg text-xs font-bold ${
        primary
          ? "bg-[#ffc107] text-neutral-900 active:bg-[#e0aa06]"
          : danger
            ? "border border-red-200 text-red-500 active:bg-red-50"
            : "border border-neutral-200 text-neutral-600 active:bg-neutral-50"
      }`}
    >
      {label}
    </button>
  );
}

/* ---------------- 用户积分面板 ---------------- */
function UsersPanel() {
  const utils = trpc.useUtils();
  const { data: users } = trpc.admin.users.useQuery();
  const { user: me } = useAuth();
  const adjust = trpc.admin.adjustPoints.useMutation({
    onSuccess: async (_, vars) => {
      toast.success(`已调整 ${vars.delta > 0 ? "+" : ""}${fmtPoints(vars.delta)} 积分`);
      setOpenFor(null);
      setDelta("");
      setReason("");
      await Promise.all([utils.admin.users.invalidate(), utils.admin.pointsLogs.invalidate()]);
    },
    onError: (e) => toast.error(e.message),
  });

  const [openFor, setOpenFor] = useState<number | null>(null);
  const [delta, setDelta] = useState("");
  const [reason, setReason] = useState("");

  if (!users) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">加载中…</div>;
  }

  return (
    <div className="flex-1 overflow-y-auto px-3 py-3 pb-6 space-y-2.5">
      {users.map((u) => (
        <div key={u.id} className="bg-white rounded-xl border border-neutral-100 p-3.5 shadow-sm">
          <div className="flex items-center gap-3">
            <Avatar name={u.name ?? "?"} url={u.avatar} size="w-10 h-10 text-sm" />
            <div className="flex-1">
              <div className="text-sm font-bold flex items-center gap-1.5">
                {u.name ?? "未命名用户"}
                {u.role === "admin" && (
                  <span className="text-[10px] bg-neutral-900 text-white rounded-full px-1.5 py-0.5">店主</span>
                )}
                {u.id === me?.id && <span className="text-[10px] text-neutral-400">（我）</span>}
              </div>
              <div className="text-xs text-neutral-400 mt-0.5">
                积分 <span className="font-bold text-[#f5a623]">{fmtPoints(u.points)}</span>
              </div>
            </div>
            <button
              onClick={() => setOpenFor(openFor === u.id ? null : u.id)}
              className="text-xs font-bold border border-neutral-200 rounded-full px-3 py-1.5 active:bg-neutral-50"
            >
              调整积分
            </button>
          </div>

          {openFor === u.id && (
            <div className="mt-3 pt-3 border-t border-neutral-50 space-y-2">
              <div className="flex gap-2">
                <button
                  onClick={() => setDelta((d) => (d.startsWith("-") ? d.slice(1) : `-${d || "10"}`))}
                  className="w-9 h-9 rounded-lg border border-neutral-200 text-sm active:bg-neutral-50"
                  aria-label="减少"
                >
                  −
                </button>
                <input
                  type="number"
                  value={delta}
                  onChange={(e) => setDelta(e.target.value)}
                  placeholder="积分变动，如 50 或 -20"
                  className="flex-1 text-sm border border-neutral-200 rounded-lg px-3 py-2 outline-none focus:border-neutral-400"
                />
                <button
                  onClick={() => setDelta((d) => (d.startsWith("-") ? `-${Math.abs(Number(d) || 10)}` : d || "10"))}
                  className="w-9 h-9 rounded-lg border border-neutral-200 text-sm active:bg-neutral-50"
                  aria-label="增加"
                >
                  +
                </button>
              </div>
              <input
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="原因，如：表现奖励 / 手动扣减"
                maxLength={100}
                className="w-full text-sm border border-neutral-200 rounded-lg px-3 py-2 outline-none focus:border-neutral-400"
              />
              <button
                disabled={adjust.isPending || !delta || !reason.trim()}
                onClick={() =>
                  adjust.mutate({ userId: u.id, delta: Number(delta), reason: reason.trim() })
                }
                className="w-full py-2.5 rounded-lg bg-neutral-900 text-white text-sm font-bold active:bg-neutral-700 disabled:opacity-40"
              >
                确认调整
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/* ---------------- 积分流水面板 ---------------- */
function LogsPanel() {
  const { data: logs } = trpc.admin.pointsLogs.useQuery();

  if (!logs) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">加载中…</div>;
  }
  if (logs.length === 0) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-300">暂无流水记录</div>;
  }

  return (
    <div className="flex-1 overflow-y-auto px-3 py-3 pb-6">
      <div className="bg-white rounded-xl border border-neutral-100 divide-y divide-neutral-50">
        {logs.map((l) => (
          <div key={l.id} className="px-3.5 py-3 flex justify-between items-center">
            <div>
              <div className="text-sm text-neutral-800">
                {l.user?.name ?? "未知用户"} · {l.reason}
              </div>
              <div className="text-[11px] text-neutral-400 mt-0.5">{fmtTime(l.createdAt)}</div>
            </div>
            <span className={`font-bold text-sm ${l.delta >= 0 ? "text-emerald-600" : "text-[#ff5e5e]"}`}>
              {l.delta >= 0 ? "+" : ""}{fmtPoints(l.delta)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- 菜单管理面板 ---------------- */
const COLOR_PRESETS = [
  { bg: "#eef2ff", color: "#4f63ff" },
  { bg: "#ffeef0", color: "#ff4757" },
  { bg: "#ecfdf5", color: "#10b981" },
  { bg: "#f5f3ff", color: "#8b5cf6" },
  { bg: "#eff6ff", color: "#3b82f6" },
  { bg: "#f3f4f6", color: "#6b7280" },
  { bg: "#fff1f2", color: "#f43f5e" },
];

function MenuPanel() {
  const utils = trpc.useUtils();
  const { data: menu } = trpc.admin.menuAdmin.useQuery();
  const toggle = trpc.admin.toggleGoods.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.admin.menuAdmin.invalidate(), utils.shop.menu.invalidate()]);
    },
    onError: (e) => toast.error(e.message),
  });
  const save = trpc.admin.saveGoods.useMutation({
    onSuccess: async () => {
      toast.success("商品已保存");
      setEditing(null);
      await Promise.all([utils.admin.menuAdmin.invalidate(), utils.shop.menu.invalidate()]);
    },
    onError: (e) => toast.error(e.message),
  });

  const [editing, setEditing] = useState<{
    id?: number;
    categoryId: number;
    name: string;
    description: string;
    points: string;
    tag: string;
    icon: string;
    bg: string;
    color: string;
  } | null>(null);

  if (!menu) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">加载中…</div>;
  }

  const openNew = (categoryId: number) =>
    setEditing({ categoryId, name: "", description: "", points: "15.8", tag: "", icon: "新", ...COLOR_PRESETS[0] });

  return (
    <div className="flex-1 overflow-y-auto px-3 py-3 pb-6 space-y-4">
      <button
        onClick={() => menu[0] && openNew(menu[0].id)}
        className="w-full py-3 rounded-xl bg-neutral-900 text-white text-sm font-bold active:bg-neutral-700"
      >
        ＋ 新增商品
      </button>

      {menu.map((c) => (
        <div key={c.id}>
          <div className="text-xs font-bold text-neutral-400 mb-1.5 flex justify-between items-center">
            {c.name}
            <button onClick={() => openNew(c.id)} className="text-neutral-900 font-normal text-xs underline">
              添加
            </button>
          </div>
          <div className="bg-white rounded-xl border border-neutral-100 divide-y divide-neutral-50">
            {c.goods.map((g) => (
              <div key={g.id} className="px-3.5 py-2.5 flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center font-bold font-serif text-sm shrink-0"
                  style={{ background: g.bg, color: g.color, opacity: g.available ? 1 : 0.35 }}
                >
                  {g.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className={`text-sm font-bold truncate ${g.available ? "" : "text-neutral-300 line-through"}`}>
                    {g.name}
                    {g.tag && <span className="ml-1 text-[10px] text-[#ff5e5e]">[{g.tag}]</span>}
                  </div>
                  <div className="text-[11px] text-neutral-400">{fmtPoints(g.points)} 积分</div>
                </div>
                <button
                  onClick={() =>
                    setEditing({
                      id: g.id,
                      categoryId: g.categoryId,
                      name: g.name,
                      description: g.description ?? "",
                      points: String(g.points),
                      tag: g.tag ?? "",
                      icon: g.icon,
                      bg: g.bg,
                      color: g.color,
                    })
                  }
                  className="text-xs text-neutral-500 border border-neutral-200 rounded-full px-2.5 py-1 active:bg-neutral-50"
                >
                  编辑
                </button>
                <button
                  onClick={() => toggle.mutate({ goodsId: g.id, available: !g.available })}
                  className={`text-xs rounded-full px-2.5 py-1 border ${
                    g.available
                      ? "border-neutral-200 text-neutral-500"
                      : "border-emerald-200 text-emerald-600"
                  }`}
                >
                  {g.available ? "下架" : "上架"}
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* 编辑弹层 */}
      {editing && (
        <>
          <div className="absolute inset-0 bg-black/50 z-40" onClick={() => setEditing(null)} />
          <div className="absolute left-0 right-0 bottom-0 bg-white rounded-t-2xl z-50 p-4 pb-8 space-y-2.5 max-h-[85%] overflow-y-auto">
            <div className="text-sm font-bold mb-1">{editing.id ? "编辑商品" : "新增商品"}</div>
            <input
              value={editing.name}
              onChange={(e) => setEditing({ ...editing, name: e.target.value })}
              placeholder="商品名称"
              className="w-full text-sm border border-neutral-200 rounded-lg px-3 py-2.5 outline-none focus:border-neutral-400"
            />
            <div className="flex gap-2">
              <input
                type="number"
                value={editing.points}
                onChange={(e) => setEditing({ ...editing, points: e.target.value })}
                placeholder="积分"
                className="w-28 text-sm border border-neutral-200 rounded-lg px-3 py-2.5 outline-none focus:border-neutral-400"
              />
              <input
                value={editing.tag}
                onChange={(e) => setEditing({ ...editing, tag: e.target.value })}
                placeholder="标签（可选，如 招牌）"
                className="flex-1 text-sm border border-neutral-200 rounded-lg px-3 py-2.5 outline-none focus:border-neutral-400"
              />
              <input
                value={editing.icon}
                onChange={(e) => setEditing({ ...editing, icon: e.target.value.slice(0, 1) || "·" })}
                placeholder="字"
                className="w-14 text-sm border border-neutral-200 rounded-lg px-3 py-2.5 outline-none focus:border-neutral-400 text-center"
              />
            </div>
            <textarea
              value={editing.description}
              onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              placeholder="描述（可选）"
              rows={2}
              maxLength={200}
              className="w-full text-sm border border-neutral-200 rounded-lg px-3 py-2.5 outline-none focus:border-neutral-400 resize-none"
            />
            <div className="flex gap-2 items-center">
              <span className="text-xs text-neutral-400 shrink-0">底色</span>
              {COLOR_PRESETS.map((p) => (
                <button
                  key={p.bg}
                  onClick={() => setEditing({ ...editing, bg: p.bg, color: p.color })}
                  aria-label={p.bg}
                  className={`w-7 h-7 rounded-full border-2 ${
                    editing.bg === p.bg ? "border-neutral-900" : "border-transparent"
                  }`}
                  style={{ background: p.bg }}
                />
              ))}
            </div>
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setEditing(null)}
                className="flex-1 py-2.5 rounded-full border border-neutral-200 text-sm text-neutral-600"
              >
                取消
              </button>
              <button
                disabled={save.isPending || !editing.name.trim() || !Number(editing.points)}
                onClick={() =>
                  save.mutate({
                    id: editing.id,
                    categoryId: editing.categoryId,
                    name: editing.name,
                    description: editing.description || undefined,
                    points: Number(editing.points),
                    tag: editing.tag || undefined,
                    icon: editing.icon,
                    bg: editing.bg,
                    color: editing.color,
                  })
                }
                className="flex-[2] py-2.5 rounded-full bg-[#ffc107] text-neutral-900 text-sm font-bold active:bg-[#e0aa06] disabled:opacity-40"
              >
                保存
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
