export function fmtPoints(n: number): string {
  return (Math.round(n * 10) / 10).toString();
}

export function fmtTime(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${date.getMonth() + 1}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
