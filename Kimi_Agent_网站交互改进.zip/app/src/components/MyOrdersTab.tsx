import { trpc } from "@/providers/trpc";
import { ORDER_STATUS_LABELS } from "@contracts/constants";
import { fmtPoints, fmtTime } from "@/lib/format";

const STATUS_STYLE: Record<string, string> = {
  pending: "bg-amber-50 text-amber-600 border-amber-200",
  accepted: "bg-blue-50 text-blue-600 border-blue-200",
  completed: "bg-emerald-50 text-emerald-600 border-emerald-200",
  cancelled: "bg-neutral-100 text-neutral-400 border-neutral-200",
};

export default function MyOrdersTab() {
  const { data: orders, isLoading } = trpc.shop.myOrders.useQuery();

  if (isLoading) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">加载中…</div>;
  }
  if (!orders || orders.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-2 text-neutral-400">
        <span className="text-4xl">🧾</span>
        <span className="text-sm">还没有订单，去点单页逛逛吧</span>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 pb-8 space-y-3">
      {orders.map((o) => (
        <div key={o.id} className="bg-white rounded-xl border border-neutral-100 p-4 shadow-sm">
          <div className="flex justify-between items-center mb-2.5">
            <span className="text-xs text-neutral-400">订单 #{o.id} · {fmtTime(o.createdAt)}</span>
            <span className={`text-[11px] px-2 py-0.5 rounded-full border ${STATUS_STYLE[o.status]}`}>
              {ORDER_STATUS_LABELS[o.status] ?? o.status}
            </span>
          </div>
          <div className="space-y-1">
            {(o.items as Array<{ name: string; points: number; qty: number }>).map((it, idx) => (
              <div key={idx} className="flex justify-between text-sm">
                <span className="text-neutral-700">
                  {it.name} <span className="text-neutral-400">×{it.qty}</span>
                </span>
                <span className="text-neutral-500">{fmtPoints(it.points * it.qty)} 积分</span>
              </div>
            ))}
          </div>
          {o.note && (
            <div className="text-xs text-neutral-400 mt-2 bg-neutral-50 rounded-lg px-2.5 py-1.5">留言：{o.note}</div>
          )}
          <div className="flex justify-between items-center mt-2.5 pt-2.5 border-t border-neutral-50 text-sm">
            <span className="text-neutral-400 text-xs">含打包费 {fmtPoints(o.packFee)} 积分</span>
            <span className="font-bold">合计 {fmtPoints(o.totalPoints)} 积分</span>
          </div>
        </div>
      ))}
    </div>
  );
}
