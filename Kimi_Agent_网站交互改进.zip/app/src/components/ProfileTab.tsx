import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { fmtPoints, fmtTime } from "@/lib/format";

function Avatar({ name, url, size }: { name: string; url?: string | null; size: string }) {
  const [err, setErr] = useState(false);
  if (url && !err) {
    return (
      <img
        src={url}
        alt={name}
        referrerPolicy="no-referrer"
        onError={() => setErr(true)}
        className={`${size} rounded-full bg-neutral-100 object-cover shrink-0`}
      />
    );
  }
  return (
    <div className={`${size} rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold shrink-0`}>
      {name.slice(0, 1)}
    </div>
  );
}

export default function ProfileTab() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { data: logs } = trpc.shop.myPointsLogs.useQuery();

  if (!user) return null;
  const isAdmin = user.role === "admin";

  return (
    <div className="flex-1 overflow-y-auto px-4 py-5 pb-8">
      {/* 用户信息卡 */}
      <div className="bg-white rounded-2xl border border-neutral-100 p-5 flex items-center gap-4 shadow-sm">
        <Avatar name={user.name ?? "?"} url={user.avatar} size="w-14 h-14 text-lg" />
        <div className="flex-1">
          <div className="font-bold text-base">{user.name ?? "未命名用户"}</div>
          <div className="text-xs text-neutral-400 mt-0.5">
            {isAdmin ? "店主（管理员）" : "使用者"}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xl font-bold text-[#f5a623]">{fmtPoints(user.points)}</div>
          <div className="text-[11px] text-neutral-400">当前积分</div>
        </div>
      </div>

      {isAdmin && (
        <button
          onClick={() => navigate("/admin")}
          className="w-full mt-4 bg-neutral-900 text-white rounded-xl py-3.5 text-sm font-bold active:bg-neutral-700"
        >
          🔔 进入管理后台（接单 / 积分管理）
        </button>
      )}

      {/* 积分流水 */}
      <div className="mt-6">
        <div className="text-sm font-bold mb-2.5">积分明细</div>
        {!logs || logs.length === 0 ? (
          <div className="text-center text-neutral-300 text-sm py-8">暂无积分记录</div>
        ) : (
          <div className="bg-white rounded-xl border border-neutral-100 divide-y divide-neutral-50">
            {logs.map((l) => (
              <div key={l.id} className="px-4 py-3 flex justify-between items-center">
                <div>
                  <div className="text-sm text-neutral-800">{l.reason}</div>
                  <div className="text-[11px] text-neutral-400 mt-0.5">{fmtTime(l.createdAt)}</div>
                </div>
                <span className={`font-bold text-sm ${l.delta >= 0 ? "text-emerald-600" : "text-[#ff5e5e]"}`}>
                  {l.delta >= 0 ? "+" : ""}{fmtPoints(l.delta)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={logout}
        className="w-full mt-6 border border-neutral-200 rounded-xl py-3 text-sm text-neutral-500 active:bg-neutral-50"
      >
        退出登录
      </button>
    </div>
  );
}
