import { useMemo, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { PACK_FEE } from "@contracts/constants";
import { fmtPoints } from "@/lib/format";

type Cart = Record<number, number>;

export default function OrderTab() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: menu, isLoading } = trpc.shop.menu.useQuery();
  const placeOrder = trpc.shop.placeOrder.useMutation({
    onSuccess: async (res) => {
      setCart({});
      setNote("");
      setPanelOpen(false);
      toast.success(`下单成功！已扣除 ${fmtPoints(res.total)} 积分`);
      await Promise.all([
        utils.shop.myOrders.invalidate(),
        utils.auth.me.invalidate(),
      ]);
    },
    onError: (e) => toast.error(e.message),
  });

  const [cart, setCart] = useState<Cart>({});
  const [activeCat, setActiveCat] = useState(0);
  const [panelOpen, setPanelOpen] = useState(false);
  const [note, setNote] = useState("");

  const goodsById = useMemo(() => {
    const m = new Map<number, { name: string; points: number }>();
    menu?.forEach((c) => c.goods.forEach((g) => m.set(g.id, { name: g.name, points: g.points })));
    return m;
  }, [menu]);

  const cartList = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const g = goodsById.get(Number(id));
          return g ? { id: Number(id), ...g, qty } : null;
        })
        .filter((x): x is NonNullable<typeof x> => !!x),
    [cart, goodsById],
  );

  const sum = cartList.reduce((acc, i) => acc + i.points * i.qty, 0);
  const count = cartList.reduce((acc, i) => acc + i.qty, 0);
  const total = count > 0 ? sum + PACK_FEE : 0;
  const notEnough = !!user && total > user.points;

  const change = (id: number, delta: number) => {
    setCart((prev) => {
      const next = { ...prev };
      const v = (next[id] ?? 0) + delta;
      if (v <= 0) delete next[id];
      else next[id] = v;
      return next;
    });
  };

  const submit = () => {
    if (cartList.length === 0) return;
    if (notEnough) {
      toast.error("积分不足哦~");
      return;
    }
    placeOrder.mutate({
      items: cartList.map((i) => ({ goodsId: i.id, qty: i.qty })),
      note: note.trim() || undefined,
    });
  };

  if (isLoading) {
    return <div className="flex-1 flex items-center justify-center text-sm text-neutral-400">菜单加载中…</div>;
  }

  return (
    <>
      {/* 主体：左分类 + 右商品 */}
      <div className="flex-1 flex overflow-hidden border-t border-neutral-100">
        <div className="w-[85px] bg-neutral-50 overflow-y-auto shrink-0 pb-24">
          {menu?.map((c, i) => (
            <button
              key={c.id}
              onClick={() => {
                setActiveCat(i);
                document.getElementById(`cat-anchor-${i}`)?.scrollIntoView({ behavior: "smooth" });
              }}
              className={`w-full text-left px-2 py-4 text-[13px] leading-snug relative transition-colors ${
                activeCat === i ? "bg-white font-bold text-neutral-900 before:absolute before:left-0 before:top-[15px] before:bottom-[15px] before:w-1 before:bg-neutral-900 before:rounded-r" : "text-neutral-500"
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="flex-1 bg-white overflow-y-auto pl-3 pr-4 pb-32" id="goods-scroll">
          {menu?.map((c, i) => (
            <div key={c.id} id={`cat-anchor-${i}`}>
              <div className="text-sm font-bold pt-4 pb-2.5 sticky top-0 bg-white z-10">{c.name}</div>
              {c.goods.map((g) => {
                const qty = cart[g.id] ?? 0;
                return (
                  <div key={g.id} className="flex py-3 border-b border-neutral-50">
                    <div
                      className="w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold font-serif shrink-0"
                      style={{ background: g.bg, color: g.color }}
                    >
                      {g.icon}
                    </div>
                    <div className="flex-1 ml-3 flex flex-col justify-between">
                      <div>
                        <div className="text-[15px] font-bold flex items-center gap-1.5">
                          {g.name}
                          {g.tag && (
                            <span className="text-[10px] text-[#ff5e5e] bg-[#ffeeee] px-1 rounded font-normal">{g.tag}</span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-400 mt-1 line-clamp-1">{g.description}</div>
                      </div>
                      <div className="flex justify-between items-center mt-1.5">
                        <div className="text-[15px] font-bold">
                          {fmtPoints(g.points)}<span className="text-[11px] font-normal ml-0.5">积分</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {qty > 0 && (
                            <>
                              <button
                                aria-label="减少"
                                onClick={() => change(g.id, -1)}
                                className="w-[26px] h-[26px] rounded border border-neutral-200 bg-neutral-50 text-neutral-600 text-lg flex items-center justify-center active:bg-neutral-200"
                              >
                                −
                              </button>
                              <span className="text-sm font-bold min-w-[14px] text-center">{qty}</span>
                            </>
                          )}
                          <button
                            aria-label="增加"
                            onClick={() => change(g.id, 1)}
                            className="w-[26px] h-[26px] rounded border border-neutral-200 bg-white text-neutral-800 text-lg flex items-center justify-center active:bg-neutral-200"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* 购物车底条 */}
      <div
        className="absolute bottom-[60px] left-3 right-3 h-[50px] bg-[#1a1a1a] rounded-full flex items-center px-3 z-40 text-white shadow-lg cursor-pointer"
        onClick={() => count > 0 && setPanelOpen(true)}
      >
        <div className="relative w-11 h-11 bg-[#333] rounded-full flex items-center justify-center -mt-3 border-4 border-[#1a1a1a] box-content">
          🛒
          {count > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#ff4d4f] text-[11px] font-bold min-w-[18px] h-[18px] rounded-full flex items-center justify-center px-1 border border-white">
              {count}
            </span>
          )}
        </div>
        <div className="flex-1 ml-3">
          <div className="text-lg font-bold">
            {fmtPoints(total)}<span className="text-xs font-normal ml-0.5">积分</span>
          </div>
          <div className="text-[11px] text-neutral-400">
            {count > 0 ? `另需打包费${PACK_FEE}积分` : "未选购商品"}
          </div>
        </div>
        <button
          disabled={count === 0 || placeOrder.isPending}
          onClick={(e) => {
            e.stopPropagation();
            setPanelOpen(true);
          }}
          className={`rounded-full px-5 py-2 text-sm font-bold ${
            count > 0 ? "bg-[#ffc107] text-neutral-900 active:bg-[#e0aa06]" : "bg-neutral-600 text-neutral-400"
          }`}
        >
          去结算
        </button>
      </div>

      {/* 购物车弹窗 */}
      {panelOpen && (
        <>
          <div className="absolute inset-0 bg-black/50 z-40" onClick={() => setPanelOpen(false)} />
          <div className="absolute left-0 right-0 bottom-[60px] bg-white rounded-t-2xl z-50 flex flex-col max-h-[70%]">
            <div className="px-4 py-3.5 flex justify-between items-center border-b border-neutral-100">
              <span className="text-sm font-bold">已选商品</span>
              <button
                className="text-xs text-neutral-400 px-1 py-1"
                onClick={() => {
                  setCart({});
                  setNote("");
                }}
              >
                清空
              </button>
            </div>
            <div className="overflow-y-auto px-4">
              {cartList.map((i) => (
                <div key={i.id} className="flex items-center py-3 border-b border-neutral-50">
                  <div className="flex-1 text-sm font-bold">{i.name}</div>
                  <div className="font-bold text-[15px] mr-3">
                    {fmtPoints(i.points * i.qty)}<span className="text-[11px] font-normal">积分</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      aria-label="减少"
                      onClick={() => change(i.id, -1)}
                      className="w-[26px] h-[26px] rounded border border-neutral-200 bg-neutral-50 text-neutral-600 flex items-center justify-center active:bg-neutral-200"
                    >
                      −
                    </button>
                    <span className="text-sm font-bold min-w-[14px] text-center">{i.qty}</span>
                    <button
                      aria-label="增加"
                      onClick={() => change(i.id, 1)}
                      className="w-[26px] h-[26px] rounded border border-neutral-200 flex items-center justify-center active:bg-neutral-200"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="px-4 py-3 border-t border-neutral-100 bg-neutral-50 rounded-b-none">
              <input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="给店主捎句话（可选）"
                maxLength={200}
                className="w-full text-sm bg-white border border-neutral-200 rounded-lg px-3 py-2 mb-3 outline-none focus:border-neutral-400"
              />
              <div className="flex justify-between items-center mb-3 text-sm">
                <span className="text-neutral-600">合计</span>
                <span className="text-lg font-bold">{fmtPoints(total)} 积分</span>
              </div>
              <button
                disabled={placeOrder.isPending}
                onClick={submit}
                className="w-full h-11 bg-[#ffc107] text-neutral-900 rounded-full text-base font-bold active:bg-[#e0aa06] disabled:opacity-60"
              >
                {placeOrder.isPending ? "提交中…" : notEnough ? "积分不足" : "确认下单"}
              </button>
            </div>
          </div>
        </>
      )}
    </>
  );
}
