import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  double,
  int,
  timestamp,
  boolean,
  json,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  points: double("points").notNull().default(999),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// 菜单分类
export const categories = mysqlTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    sort: int("sort").notNull().default(0),
  },
  (t) => [index("categories_sort_idx").on(t.sort)],
);

// 菜单商品
export const goods = mysqlTable(
  "goods",
  {
    id: serial("id").primaryKey(),
    categoryId: bigint("categoryId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => categories.id),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    points: double("points").notNull(),
    tag: varchar("tag", { length: 50 }),
    icon: varchar("icon", { length: 10 }).notNull().default("·"),
    bg: varchar("bg", { length: 20 }).notNull().default("#f3f4f6"),
    color: varchar("color", { length: 20 }).notNull().default("#6b7280"),
    available: boolean("available").notNull().default(true),
    sort: int("sort").notNull().default(0),
  },
  (t) => [index("goods_category_idx").on(t.categoryId)],
);

// 订单
export const orders = mysqlTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    // 下单时的商品快照 [{goodsId, name, points, qty}]
    items: json("items").$type<OrderItem[]>().notNull(),
    totalPoints: double("totalPoints").notNull(),
    packFee: double("packFee").notNull().default(0),
    note: varchar("note", { length: 500 }),
    status: mysqlEnum("status", ["pending", "accepted", "completed", "cancelled"])
      .notNull()
      .default("pending"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => [index("orders_user_idx").on(t.userId), index("orders_created_idx").on(t.createdAt)],
);

export type OrderItem = {
  goodsId: number;
  name: string;
  points: number;
  qty: number;
};

// 积分流水
export const pointsLogs = mysqlTable(
  "pointsLogs",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    delta: double("delta").notNull(),
    reason: varchar("reason", { length: 255 }).notNull(),
    orderId: bigint("orderId", { mode: "number", unsigned: true }),
    operatorId: bigint("operatorId", { mode: "number", unsigned: true }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [index("pointsLogs_user_idx").on(t.userId)],
);
