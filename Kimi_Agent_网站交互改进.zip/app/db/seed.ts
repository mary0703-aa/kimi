import { getDb } from "../api/queries/connection";
import { categories, goods } from "./schema";

const CATS = [
  "线下碰一碰",
  "网络一线牵",
  "如果变成伤心豆怎么办",
  "待开发项目",
];

const GOODS: Array<{
  cat: number;
  name: string;
  desc: string;
  pts: number;
  icon: string;
  bg: string;
  color: string;
  tag?: string;
}> = [
  { cat: 0, name: "出来走一走", desc: "据说和爱的人在一起会很幸福", pts: 9.9, icon: "出", bg: "#eef2ff", color: "#4f63ff" },
  { cat: 0, name: "要陪你吃大餐！", desc: "用美食治愈会感到开心吗", pts: 9.9, icon: "要", bg: "#ffeef0", color: "#ff4757", tag: "招牌" },
  { cat: 0, name: "来看电影吧！", desc: "诚邀你一起去观看4d电影", pts: 15.8, icon: "来", bg: "#ecfdf5", color: "#10b981", tag: "招牌" },
  { cat: 0, name: "一起去洗浴！", desc: "泡澡会放松心情哦", pts: 15.8, icon: "-", bg: "#f5f3ff", color: "#8b5cf6" },
  { cat: 0, name: "解锁世界地图ing", desc: "来一趟说走就走的旅行吧", pts: 15.8, icon: "解", bg: "#f3f4f6", color: "#6b7280" },
  { cat: 1, name: "相约瓦罗兰特", desc: "想来一把刺激快乐的无畏契约...", pts: 15.8, icon: "相", bg: "#eff6ff", color: "#3b82f6" },
  { cat: 1, name: "一起刷抖音", desc: "申请查看抖音使用时长", pts: 15.8, icon: "-", bg: "#ffeef0", color: "#f43f5e" },
  { cat: 1, name: "尝试新游戏", desc: "来一款我们都没有玩过的游戏", pts: 15.8, icon: "尝", bg: "#ecfdf5", color: "#10b981" },
  { cat: 1, name: "剪一个视频", desc: "看看谁更会剪视频", pts: 15.8, icon: "剪", bg: "#f5f3ff", color: "#8b5cf6" },
  { cat: 1, name: "你画我猜", desc: "非常经典的游戏", pts: 15.8, icon: "你", bg: "#f3f4f6", color: "#6b7280" },
  { cat: 2, name: "来个抱抱", desc: " ", pts: 15.8, icon: "来", bg: "#ecfdf5", color: "#10b981" },
  { cat: 2, name: "亲亲你呀", desc: " ", pts: 15.8, icon: "亲", bg: "#f5f3ff", color: "#8b5cf6" },
  { cat: 2, name: "给你炒盘菜", desc: "吃完不包活", pts: 15.8, icon: "给", bg: "#f3f4f6", color: "#9ca3af" },
  { cat: 2, name: "在你身边", desc: "暖暖的很贴心", pts: 15.8, icon: "在", bg: "#eff6ff", color: "#3b82f6" },
  { cat: 2, name: "想打视频吗", desc: "如果我不在你身边的话", pts: 15.8, icon: "想", bg: "#fff1f2", color: "#f43f5e" },
  { cat: 3, name: "公园let is go!", desc: "一起慢慢走时间也会变慢吗", pts: 15.8, icon: "公", bg: "#f5f3ff", color: "#8b5cf6" },
  { cat: 3, name: "想去逛街吗？", desc: "如何拥有一套女朋友精心挑选...", pts: 15.8, icon: "想", bg: "#f3f4f6", color: "#6b7280" },
  { cat: 3, name: "小猫喵喵喵", desc: "去摸摸可爱的猫咪吧！", pts: 15.8, icon: "小", bg: "#eff6ff", color: "#3b82f6" },
  { cat: 3, name: "尝试DIY", desc: "来比较一下谁更胜一筹", pts: 15.8, icon: "尝", bg: "#ffeef0", color: "#f43f5e" },
];

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  const existingCats = await db.select().from(categories);
  if (existingCats.length === 0) {
    for (let i = 0; i < CATS.length; i++) {
      await db.insert(categories).values({ name: CATS[i], sort: i });
    }
    console.log(`Inserted ${CATS.length} categories`);
  } else {
    console.log("Categories already exist, skipping");
  }

  const allCats = await db.select().from(categories);
  const existingGoods = await db.select().from(goods);
  if (existingGoods.length === 0) {
    let sort = 0;
    for (const g of GOODS) {
      const category = allCats[g.cat];
      if (!category) continue;
      await db.insert(goods).values({
        categoryId: category.id,
        name: g.name,
        description: g.desc,
        points: g.pts,
        tag: g.tag ?? null,
        icon: g.icon,
        bg: g.bg,
        color: g.color,
        sort: sort++,
      });
    }
    console.log(`Inserted ${GOODS.length} goods`);
  } else {
    console.log("Goods already exist, skipping");
  }

  console.log("Done.");
  process.exit(0);
}

seed();
