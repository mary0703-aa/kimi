import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq, desc, asc } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { categories, goods, orders, pointsLogs, users } from "@db/schema";

const orderStatusSchema = z.enum(["pending", "accepted", "completed", "cancelled"]);

export const adminRouter = createRouter({
  // 全部订单（含下单人信息）
  orders: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200);
    const allUsers = await db.select().from(users);
    const byId = new Map(allUsers.map((u) => [u.id, u]));
    return rows.map((o) => ({
      ...o,
      user: byId.get(o.userId) ?? null,
    }));
  }),

  // 修改订单状态
  setOrderStatus: adminQuery
    .input(z.object({ orderId: z.number().int().positive(), status: orderStatusSchema }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [order] = await db
        .select()
        .from(orders)
        .where(eq(orders.id, input.orderId))
        .limit(1);
      if (!order) {
        throw new TRPCError({ code: "NOT_FOUND", message: "订单不存在" });
      }
      await db
        .update(orders)
        .set({ status: input.status })
        .where(eq(orders.id, input.orderId));

      // 取消订单时退回积分
      if (input.status === "cancelled" && order.status !== "cancelled") {
        await db.transaction(async (tx) => {
          const [u] = await tx
            .select()
            .from(users)
            .where(eq(users.id, order.userId))
            .limit(1)
            .for("update");
          if (!u) return;
          await tx
            .update(users)
            .set({ points: Math.round((u.points + order.totalPoints) * 10) / 10 })
            .where(eq(users.id, u.id));
          await tx.insert(pointsLogs).values({
            userId: u.id,
            delta: order.totalPoints,
            reason: `订单 #${order.id} 取消退回`,
            orderId: order.id,
            operatorId: ctx.user.id,
          });
        });
      }
      return { success: true };
    }),

  // 用户列表（积分管理）
  users: adminQuery.query(async () => {
    return getDb()
      .select({
        id: users.id,
        name: users.name,
        avatar: users.avatar,
        role: users.role,
        points: users.points,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(asc(users.id));
  }),

  // 调整用户积分
  adjustPoints: adminQuery
    .input(
      z.object({
        userId: z.number().int().positive(),
        delta: z.number().min(-100000).max(100000),
        reason: z.string().min(1, "请填写调整原因").max(255),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const newPoints = await db.transaction(async (tx) => {
        const [u] = await tx
          .select()
          .from(users)
          .where(eq(users.id, input.userId))
          .limit(1)
          .for("update");
        if (!u) throw new TRPCError({ code: "NOT_FOUND", message: "用户不存在" });
        const np = Math.round((u.points + input.delta) * 10) / 10;
        if (np < 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "调整后积分不能为负数" });
        }
        await tx.update(users).set({ points: np }).where(eq(users.id, u.id));
        await tx.insert(pointsLogs).values({
          userId: u.id,
          delta: input.delta,
          reason: input.reason.trim(),
          operatorId: ctx.user.id,
        });
        return np;
      });
      return { success: true, newPoints };
    }),

  // 全部积分流水
  pointsLogs: adminQuery.query(async () => {
    const db = getDb();
    const logs = await db
      .select()
      .from(pointsLogs)
      .orderBy(desc(pointsLogs.createdAt))
      .limit(200);
    const allUsers = await db.select().from(users);
    const byId = new Map(allUsers.map((u) => [u.id, u]));
    return logs.map((l) => ({ ...l, user: byId.get(l.userId) ?? null }));
  }),

  // 菜单管理（含下架商品）
  menuAdmin: adminQuery.query(async () => {
    const db = getDb();
    const cats = await db.select().from(categories).orderBy(categories.sort);
    const allGoods = await db.select().from(goods).orderBy(goods.sort);
    return cats.map((c) => ({
      ...c,
      goods: allGoods.filter((g) => g.categoryId === c.id),
    }));
  }),

  // 新增 / 编辑商品
  saveGoods: adminQuery
    .input(
      z.object({
        id: z.number().int().positive().optional(),
        categoryId: z.number().int().positive(),
        name: z.string().min(1, "请填写名称").max(255),
        description: z.string().max(500).optional(),
        points: z.number().positive("积分需大于 0").max(100000),
        tag: z.string().max(50).optional(),
        icon: z.string().min(1).max(10),
        bg: z.string().min(1).max(20),
        color: z.string().min(1).max(20),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const values = {
        categoryId: input.categoryId,
        name: input.name.trim(),
        description: input.description?.trim() || null,
        points: input.points,
        tag: input.tag?.trim() || null,
        icon: input.icon,
        bg: input.bg,
        color: input.color,
      };
      if (input.id) {
        await db.update(goods).set(values).where(eq(goods.id, input.id));
        return { id: input.id };
      }
      const [row] = await db
        .select({ maxSort: goods.sort })
        .from(goods)
        .orderBy(desc(goods.sort))
        .limit(1);
      const [inserted] = await db
        .insert(goods)
        .values({ ...values, sort: (row?.maxSort ?? 0) + 1 })
        .$returningId();
      return { id: inserted.id };
    }),

  // 上架 / 下架
  toggleGoods: adminQuery
    .input(z.object({ goodsId: z.number().int().positive(), available: z.boolean() }))
    .mutation(async ({ input }) => {
      await getDb()
        .update(goods)
        .set({ available: input.available })
        .where(eq(goods.id, input.goodsId));
      return { success: true };
    }),
});
