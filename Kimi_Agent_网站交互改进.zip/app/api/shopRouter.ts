import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq, desc, inArray } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { categories, goods, orders, pointsLogs, users } from "@db/schema";
import { PACK_FEE } from "@contracts/constants";

export const shopRouter = createRouter({
  // 菜单（顾客视角，仅上架商品）
  menu: authedQuery.query(async () => {
    const db = getDb();
    const cats = await db.select().from(categories).orderBy(categories.sort);
    const allGoods = await db
      .select()
      .from(goods)
      .where(eq(goods.available, true))
      .orderBy(goods.sort);
    return cats.map((c) => ({
      ...c,
      goods: allGoods.filter((g) => g.categoryId === c.id),
    }));
  }),

  // 提交订单：服务端计价、校验并扣除积分
  placeOrder: authedQuery
    .input(
      z.object({
        items: z
          .array(
            z.object({
              goodsId: z.number().int().positive(),
              qty: z.number().int().positive().max(99),
            }),
          )
          .min(1),
        note: z.string().max(500).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const ids = input.items.map((i) => i.goodsId);
      const goodsRows = await db
        .select()
        .from(goods)
        .where(inArray(goods.id, ids));

      if (goodsRows.length !== new Set(ids).size) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "存在无效商品，请刷新菜单后重试",
        });
      }
      const unavailable = goodsRows.filter((g) => !g.available);
      if (unavailable.length > 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `「${unavailable[0].name}」已下架，请从购物车移除后重试`,
        });
      }

      const snapshot = input.items.map((i) => {
        const g = goodsRows.find((r) => r.id === i.goodsId)!;
        return { goodsId: g.id, name: g.name, points: g.points, qty: i.qty };
      });
      const sum = snapshot.reduce((acc, s) => acc + s.points * s.qty, 0);
      const packFee = PACK_FEE;
      const total = sum + packFee;

      const orderId = await db.transaction(async (tx) => {
        const [u] = await tx
          .select()
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .limit(1)
          .for("update");
        if (!u || u.points < total) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "积分不足哦~",
          });
        }
        const newPoints = Math.round((u.points - total) * 10) / 10;
        await tx
          .update(users)
          .set({ points: newPoints })
          .where(eq(users.id, u.id));
        const [order] = await tx
          .insert(orders)
          .values({
            userId: u.id,
            items: snapshot,
            totalPoints: total,
            packFee,
            note: input.note?.trim() || null,
            status: "pending",
          })
          .$returningId();
        await tx.insert(pointsLogs).values({
          userId: u.id,
          delta: -total,
          reason: `下单消耗（订单 #${order.id}）`,
          orderId: order.id,
        });
        return order.id;
      });

      return { orderId, total };
    }),

  // 我的订单
  myOrders: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(orders)
      .where(eq(orders.userId, ctx.user.id))
      .orderBy(desc(orders.createdAt))
      .limit(100);
  }),

  // 我的积分流水
  myPointsLogs: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(pointsLogs)
      .where(eq(pointsLogs.userId, ctx.user.id))
      .orderBy(desc(pointsLogs.createdAt))
      .limit(100);
  }),
});
