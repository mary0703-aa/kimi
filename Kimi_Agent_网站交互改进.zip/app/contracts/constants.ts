export const Session = {
  cookieName: "kimi_sid",
  maxAgeMs: 365 * 24 * 60 * 60 * 1000,
} as const;

export const ErrorMessages = {
  unauthenticated: "Authentication required",
  insufficientRole: "Insufficient permissions",
} as const;

export const Paths = {
  login: "/login",
  oauthCallback: "/api/oauth/callback",
} as const;

/** 每单打包费（积分） */
export const PACK_FEE = 2;

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: "待接单",
  accepted: "已接单",
  completed: "已完成",
  cancelled: "已取消",
};
